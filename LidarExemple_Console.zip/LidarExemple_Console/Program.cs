﻿using System;
using System.Collections.Generic;
using System.Timers;
using RPLidarA1;

namespace LidarExemple_Console
{
    class Program
    {
        static RPLidarA1class rplidar; //RPLidar object
        static Timer timer; //Timer to refresh number of mesure/second
        static List<Measure> measures = new List<Measure>(); //Measures list

        static void Main(string[] args)
        {
            if (!SearchPort()) return;

            Console.WriteLine("Insert Serial Port ");
            string porta=Console.ReadLine(); //Input serial port
            bool result = rplidar.ConnectSerial(porta); //Open Serial Port
            if (!result)
            {
                Console.WriteLine("Error Opening Serial Port " + porta);
                return;
            }

            string snum = rplidar.SerialNum(); //Get RPLidar Info
            if (snum=="")
            {
                Console.WriteLine("Error retriving serial number");
                return;
            }
            Console.WriteLine(snum);

            if (!rplidar.BoostScan()) //Start BoostScan
            {
                rplidar.CloseSerial();
                Console.WriteLine("Error on start scan.");
                return;
            }

            timer = new Timer();
            timer.Interval = 500;
            timer.Elapsed += Timer_Elapsed; ; //Refresh mesure/second and graphics
            timer.AutoReset = true;
            timer.Enabled = true;
        }

        private static void Timer_Elapsed(object sender, ElapsedEventArgs e)  //Refresh Mesure
        {

            lock (rplidar.Measure_List)
            {
                foreach (Measure m in rplidar.Measure_List) //Copy Measure List
                {
                    measures.Add(m);
                }
                rplidar.Measure_List.Clear(); //Clear original List
            }

            Console.WriteLine("Mesure Read : "+measures.Count.ToString());


            for (int x = 0; x < measures.Count; x++) //Copy the measure list in point measure list
            {
                Console.WriteLine("Angle: "+ measures[x].angle.ToString() + "  Distance: "+ measures[x].distance.ToString());
            }
            measures.Clear();
            //Stop();
        }

        static void Stop()
        {
            rplidar.Stop_Scan(); //Stop Scan Thread
            rplidar.CloseSerial(); //Close serial port
            timer.Enabled=false; //Stop refresh timer
            //timer.Dispose();
        }

        static bool SearchPort () //Find Serial Ports
        {
            Console.WriteLine("Select Serial Port");
            rplidar = new RPLidarA1class();
            string[] porte = rplidar.FindSerialPorts(); //Find serial ports
            if (porte.Length == 0)
            {
                Console.WriteLine("No serial port found");
                return false;
            }
            foreach (string s in porte)
            {
                Console.WriteLine(s);
            }
            return true;
        }
    }
}
