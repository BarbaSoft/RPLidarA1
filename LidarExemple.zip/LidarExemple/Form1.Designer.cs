﻿
namespace LidarExemple
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ComboSerialPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenSerial = new System.Windows.Forms.Button();
            this.Info = new System.Windows.Forms.TextBox();
            this.measure_second = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ComboSerialPort
            // 
            this.ComboSerialPort.FormattingEnabled = true;
            this.ComboSerialPort.Location = new System.Drawing.Point(86, 12);
            this.ComboSerialPort.Name = "ComboSerialPort";
            this.ComboSerialPort.Size = new System.Drawing.Size(121, 23);
            this.ComboSerialPort.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Serial Port";
            // 
            // OpenSerial
            // 
            this.OpenSerial.Location = new System.Drawing.Point(231, 12);
            this.OpenSerial.Name = "OpenSerial";
            this.OpenSerial.Size = new System.Drawing.Size(75, 23);
            this.OpenSerial.TabIndex = 2;
            this.OpenSerial.Text = "Open Serial";
            this.OpenSerial.UseVisualStyleBackColor = true;
            this.OpenSerial.Click += new System.EventHandler(this.OnOpenSerialClicked);
            // 
            // Info
            // 
            this.Info.Location = new System.Drawing.Point(12, 52);
            this.Info.Name = "Info";
            this.Info.ReadOnly = true;
            this.Info.Size = new System.Drawing.Size(573, 23);
            this.Info.TabIndex = 3;
            // 
            // measure_second
            // 
            this.measure_second.Location = new System.Drawing.Point(608, 12);
            this.measure_second.Name = "measure_second";
            this.measure_second.ReadOnly = true;
            this.measure_second.Size = new System.Drawing.Size(76, 23);
            this.measure_second.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(511, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Measure / sec";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 195);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.measure_second);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.OpenSerial);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ComboSerialPort);
            this.Name = "Form1";
            this.Text = "Lidar Reader";
            this.Shown += new System.EventHandler(this.OnShow);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboSerialPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button OpenSerial;
        private System.Windows.Forms.TextBox Info;
        private System.Windows.Forms.TextBox measure_second;
        private System.Windows.Forms.Label label2;
    }
}

