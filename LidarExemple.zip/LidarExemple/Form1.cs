﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RPLidarA1;
using OpenTK;

namespace LidarExemple
{
    public partial class Form1 : Form
    {
        RPLidarA1class rplidar; //RPLidar object
        Timer timer; //Timer to refresh number of mesure/second
        Wrender wrender;
        List<Measure> measures = new List<Measure>(); //Measures list

        public Form1()
        {
            InitializeComponent();
        }

        private void OnShow(object sender, EventArgs e)  //On Show Main Window
        {
            rplidar = new RPLidarA1class();
            string[] porte=rplidar.FindSerialPorts(); //Find serial ports
            if (porte.Length==0)
            {
                MessageBox.Show("Serial Ports not found", "No serial", MessageBoxButtons.OK);
                return;
            }
            foreach (string s in porte)
            {
                ComboSerialPort.Items.Add(s);
            }
            ComboSerialPort.SelectedIndex=0;
        }

        private void OnOpenSerialClicked(object sender, EventArgs e) //On click Button Open-Close
        {
            if (OpenSerial.Text== "Close Serial") //Close Serial Port
            {
                rplidar.Stop_Scan(); //Stop Scan Thread
                rplidar.CloseSerial(); //Close serial port
                timer.Stop(); //Stop refresh timer
                timer.Dispose();
                measure_second.Text = "";
                OpenSerial.Text = "Open Serial";
                return;
            }

            bool result=rplidar.ConnectSerial(ComboSerialPort.SelectedItem.ToString()); //Open Serial Port
            if (result==false)
            {
                Info.Text = "Error Opening COM;";
                return;
            }

            string snum = rplidar.SerialNum(); //Get RPLidar Info

            if (snum=="") //Error on retriving Info from Lidar
            {
                rplidar.CloseSerial();
                Info.Text = "Error retriving Info from RPLidar.";
                return;
            }

            Info.Text = snum;

            if (!rplidar.BoostScan()) //Start BoostScan
            {
                rplidar.CloseSerial();
                Info.Text = "Error on start scan.";
                return;
            }

            if (result == true) OpenSerial.Text = "Close Serial";

            timer = new Timer();
            timer.Interval = 500;
            timer.Tick += Timer_Tick; //Refresh mesure/second and graphics
            timer.Start();

            GameWindow gwin = new GameWindow(800, 600); //Start OpenTK graphics
            wrender = new Wrender(gwin);
            gwin.Run();
        }

        private void Timer_Tick(object sender, EventArgs e)  //Refresh mesure/second and graphics
        {
            measure_second.Text = rplidar.measure_second.ToString();

            lock (rplidar.Measure_List)
            {
                foreach (Measure m in rplidar.Measure_List) //Copy Measure List
                {
                    measures.Add(m);
                }
                rplidar.Measure_List.Clear(); //Clear original List
            }

            Point p;
            wrender.punti.Clear();
            for (int x = 0; x < measures.Count; x++) //Copy the measure list in point measure list
            {
                p = new Point();
                p.X = (int)measures.ElementAt(x).X;
                p.Y = (int)measures.ElementAt(x).Y;
                wrender.punti.Add(p);
            }
            measures.Clear();
        }
    }
}
