﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using System.Drawing;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using OpenTK;

namespace LidarExemple
{
    class Wrender
    {
        public GameWindow rwin;
        float scala, magnify;
        float transx, transy;
        public List<Point> punti;

        public Wrender(GameWindow WindowInput)
        {
            punti = new List<Point>();
            rwin = WindowInput;
            rwin.Load += Rwin_Load;
            rwin.RenderFrame += Rwin_RenderFrame;
            rwin.UpdateFrame += Rwin_UpdateFrame;
            rwin.Closing += Rwin_Closing;
            rwin.MouseWheel += Rwin_MouseWheel;
            rwin.MouseMove += Rwin_MouseMove;
        }

        private void Rwin_MouseMove(object sender, MouseMoveEventArgs e)
        {
            if (OpenTK.Input.Mouse.GetState().IsButtonDown(MouseButton.Left))
            {
                if (e.XDelta > 0) transx = transx + 0.05f;
                if (e.XDelta < 0) transx = transx - 0.05f;
                if (e.YDelta > 0) transy = transy - 0.05f;
                if (e.YDelta < 0) transy = transy + 0.05f;
            }
        }

        private void Rwin_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
            {
                scala = scala + 0.02f;
                if (scala >= 1.0f)
                {
                    scala = 1.0f;
                    magnify = magnify + 0.1f;
                }
            }
            else
            {
                if (magnify > 1.0f)
                {
                    magnify = magnify - 0.1f;
                }
                else scala = scala - 0.02f;

                if (scala < 0)
                {
                    scala = 0;
                }
            }
        }

        private void Rwin_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            
        }

        private void Rwin_UpdateFrame(object sender, FrameEventArgs e)
        {
            
        }

        private void Rwin_RenderFrame(object sender, FrameEventArgs e)
        {
            GL.ClearColor(Color.Black);
            GL.ClearDepth(1);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            Matrix4 projMatrix = Matrix4.CreateOrthographicOffCenter(-3000, 3000, -3000, 3000, 0, 1)
                * Matrix4.CreateTranslation(transx, transy, 0) * Matrix4.CreateScale(scala);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projMatrix);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            GL.PointSize(1);
            GL.Begin(PrimitiveType.Points);
            GL.Color3(Color.Red);

            //try
            //{
            foreach (Point p in punti)
            {
                GL.Vertex2(p.X * magnify, p.Y * magnify);
            }
            //}
            //catch (Exception e)
            //{

            //}
            GL.End();
            GL.Flush();
            rwin.SwapBuffers();
        }

        private void Rwin_Load(object sender, EventArgs e)
        {
            scala = 1.0f;
            magnify = 1.0f;
            transx = 0;
            transy = 0;
            rwin.Title = "RPLidar OpenGL";
        }
    }
}
